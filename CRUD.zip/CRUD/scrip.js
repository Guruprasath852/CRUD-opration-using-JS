async function sub() {  
var dataEntered = retrieveData();
var savedata=await fetch("https://62e0d51698dd9c9df6177ef5.mockapi.io/books",{
    method:"POST",
    mode:"cors",
    body:JSON.stringify(dataEntered),
    headers: {
        "Content-Type": "application/json"
      }

});
var saveform=await fetch("https://62e0d51698dd9c9df6177ef5.mockapi.io/books");
var data=await saveform.json()


console.log(data);
var tab=document.getElementById("data")
//var loopdata=document.getElementById("form");
let table=document.createElement("tabdata");
let out="";
table.innerHTML=` <tr>
<th class="">Name</th>
<th class="">Department</th>
<th class="">Email ID</th>
<th class="">Mobile Number</th>
<th class="">Year Passed</th>
</tr>`
data.forEach(element => {
    tab.innerHTML= `<te>
    <td>${element.Name}</td>
    <td>${element.Department}</td>
    <td>${element.Email}</td>
    <td>${element.MobileNumber}</td>
    <td>${element.YearPassed}</td>
    <td>${element.YearPassed}</td>
    </tr>
    `
    table.appendChild(tab);
});
}

//data resivc from
function retrieveData() {
    var id=document.getElementById("id").value;
    var Name=document.getElementById("namee").value;
    var Department=document.getElementById("department").value;
    var Email=document.getElementById("email").value;
    var MobileNumber=document.getElementById("number").value;
    var YearPassed=document.getElementById("year").value;

    var values={Name,Department,Email,MobileNumber,YearPassed};

    return values;

}
//retrive the data in 


 async function deletePost(element) {
console.log( element.values());
    var deleteId=element.id;
    const reqObj={
        method:"DELETE",
        headers:{
            "content=type":"application/json"
        }
    }
    const responce=await fetch(`${"https://62e0d51698dd9c9df6177ef5.mockapi.io/books"}/${deleteId}`,reqObj);
    if(responce.ok){
        element.remove();
    }

}
async function updateValue(s) {
  var nes= await fetch("https://62e0d51698dd9c9df6177ef5.mockapi.io/books",s); 
   var su=nes.json;
   console.log(su.Name); 
}